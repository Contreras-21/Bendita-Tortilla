# Bendita Tortilla · Paquete completo para revisión de inversión

1. Descomprimir el ZIP completo.
2. Abrir **PLAN_Bendita_Tortilla.html** para lectura offline: gráficas incrustadas, tablas y enlaces a fuentes.
3. **PLAN_Bendita_Tortilla.md** es el documento editable solicitado. Mantener a su lado `graficas/`; todas las imágenes están incluidas.
4. `datos/` contiene estadísticas, precios, hipótesis y resultados CSV; `WDI_original/` conserva respuestas originalesAPI.
5. `anexos/` incluye modelo económico, consulta arancelaria, extractos del tratado firmado, solicitud de cotización, notas de revisión y script de cálculo.

Fecha de corte 09-10-2026. Documento 1–3.16; Alemania definido, centro Berlín y zona Moabit. Los costos y metas sin contrato están marcados como hipótesis. No se acredita vida útil propia ni rentabilidad de lanzamiento. CSV UTF-8 con BOM; separador coma y punto decimal. Las figuras 1–4 conservanPNG original; figuras 5–10 incluyen PNG y SVG. ElHTML no requiere servidor, conexión ni recursos externos para imágenes; consultar fuentes externas sí requiere conexión.

Para comprobar los seis escenarios del modelo, ejecutar `python3 anexos/calculos.py --verificar` desde la carpeta del paquete. No requiere dependencias externas. Para probar otros parámetros, modificar `datos/Parametros_modelo.csv` y ejecutar el mismo script sin la bandera: genera un CSV nuevo sin modificar el plan. Cambiar clasificación requiere adaptar la fórmula. Las fuentes primarias se listan en el documento y en `datos/Registro_fuentes.csv`.

`fuentes/` incorpora los PDF oficiales del acuerdo interino firmado y de la población registrada de Berlín, para verificar cifras y calendario sin depender de la carga del sitio.

La versión 2.1 amplía el punto 3.16 con cultura empresarial, negociación, ejemplos y fuentes S68–S71. El anexo `Cultura_y_negociacion_Alemania.md` permite consultarlo por separado.
