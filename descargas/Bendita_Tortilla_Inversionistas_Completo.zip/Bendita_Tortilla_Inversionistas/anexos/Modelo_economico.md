# Anexo económico reproducible

El modelo no es una cotización ni un pronóstico de ventas. Los precios públicos, tasas ad valorem observadas y parámetros internos se separan en CSV. El plan contiene las fórmulas y el tratamiento de IVA, valor en aduana, merma y reserva.

## Lote comercial de referencia: 411kg

| SKU | Flete estrés EUR/kg cobrable | Costo EUR/kg vendible | IVA caja EUR | Caja total EUR |
|---|---|---|---|---|
| Maíz | 4 | 9.51 | 254.73 | 3966.48 |
| Maíz | 8 | 14.78 | 395.92 | 6165.05 |
| Maíz | 12 | 20.04 | 537.11 | 8363.61 |
| Harina | 4 | 10.21 | 273.64 | 4260.93 |
| Harina | 8 | 15.48 | 414.83 | 6459.50 |
| Harina | 12 | 20.75 | 556.02 | 8658.06 |

## Muestra técnica, hasta60kg

La simulación agrega dos filas de30kg; se reparte el costo fijo total de700EUR por mitades. Tarifa estrés8EUR/kg; no se duplica el total fijo ni se aplica50/50 a ventas comerciales. Presupuesto excluye laboratorio y desarrollo.

| SKU | kg | Costo económico total EUR | IVA presupuestario EUR | Caja EUR |
|---|---|---|---|---|
| Maíz | 30 | 725.99 | 49.82 | 775.81 |
| Harina | 30 | 746.10 | 51.20 | 797.30 |

**Caja total ilustrativa: 1573.11 EUR.**

## Advertencias de interpretación concretas

El código80, EA 20 y adicional0 son supuestos del modelo, no dictamen por SKU. Si se confirma código30, reemplazar fórmula y tasa. El precio FCA no prueba margen del fabricante: medir costo productivo más costos mexicanos hasta puntoFCA. El factor1.12 no sustituye cálculo volumétrico real. El IVA de caja utiliza una base simplificada y requiere ajuste fiscal del agente. Una reserva no se contabiliza como siniestro esperado. La tarifa mínima total y el lote de una cotización pueden obligar a cambiar las hipótesis.

La cota logística del plan elimina cargos para establecer un máximo optimista; no debe usarse como precio ofertado. El modelo incluye inventario de un ciclo para calcular costo, pero la financiación debe sumar inventario en tránsito y cuentas por cobrar. Con390kg/mes y40días de tránsito supuesto habrá aproximadamente520kg vendibles de pipeline en régimen estable, además del inventario local; si los40días no se cumplen, cambia esa caja. No se confunde pipeline con lote único vendible en almacén.
