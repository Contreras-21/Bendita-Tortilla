"""Recalcula/verifica el costo del importador sin dependencias externas.
Ejecutar: python3 anexos/calculos.py --verificar
Modificar datos/Parametros_modelo.csv para probar escenarios y ejecutar sin bandera.
Las entradas son hipótesis; este cálculo no sustituye clasificación o cotización.
"""
from pathlib import Path
import csv
import math
import sys

root = Path(__file__).resolve().parents[1]
with (root/'datos/Parametros_modelo.csv').open(encoding='utf-8-sig') as f:
    params = {r['variable']:r['valor'] for r in csv.DictReader(f)}
def p(name):
    return float(params[name])
def model(sku,Q,r):
    W = p('Peso cobrable/neto')*Q
    goods = p('FCA maíz' if sku=='Maíz' else 'FCA harina')*Q
    freight = r*W
    ins = p('Seguro')*(goods+freight)
    V = goods+freight+ins
    duty = min(p('Ad valorem CN19059080')*V+p('EA')*Q/100,
               p('MAX ad valorem')*V+p('AD F/M')*Q/100)
    local = p('Servicios fijos destino')+p('Almacén y reparto variable')*Q
    reserve = p('Reserva financiera')*(V+duty+local)
    total = V+duty+local+reserve
    vendible = Q*(1-p('Merma'))
    iva = p('IVA')*(V+duty+local)
    return dict(sku=sku,Q=Q,W=W,r=r,goods=goods,freight=freight,insurance=ins,
                V=V,duty=duty,local=local,reserve=reserve,total=total,
                vendible=vendible,cost=total/vendible,IVA=iva,cash=total+iva)
Q = math.ceil(p('Ventas netas base')/(1-p('Merma')))
rows = [model(sku,Q,r) for sku in ('Maíz','Harina') for r in (4,8,12)]
if '--verificar' in sys.argv:
    with (root/'datos/Modelo_costos_escenarios.csv').open(encoding='utf-8-sig') as f:
        expected = list(csv.DictReader(f))
    assert len(expected)==len(rows)
    for actual,saved in zip(rows,expected):
        assert actual['sku']==saved['sku']
        for key,value in actual.items():
            if key!='sku':
                assert math.isclose(value,float(saved[key]),rel_tol=1e-10), (key,value,saved[key])
    print('Verificación correcta: seis escenarios; lote',Q,'kg; unidades y fórmulas coinciden.')
else:
    dest = root/'datos/Resultados_recalculados.csv'
    with dest.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print('Resultados guardados en',dest)
