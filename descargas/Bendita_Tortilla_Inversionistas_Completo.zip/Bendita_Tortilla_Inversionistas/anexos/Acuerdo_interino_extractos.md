# Extractos del texto firmado UE–México

Fuente[S47],DO2026/1528. Texto público oficial; extracción conserva líneas y nomenclaturaCN2016.

## Localización: página PDF 245

Término: This Agreement shall enter into force on the first day of the second month

```text
OJ L, 31.7.2026                                                                                                                           EN
                                                                SECTION B
                                                           Final Provisions



                                                                 Article 33.7
                                                          Territorial Application


      1.     Unless otherwise specified, this Agreement applies, with respect to the European Union, to the territories in which the
      Treaty on European Union (‘TEU’) and the TFEU apply and under the conditions laid down in those Treaties. The provisions
      concerning the tariff treatment of goods, rules of origin and origin procedures apply also to the customs territory of the
      European Union not covered by the first sentence of this paragraph. The term ‘territory’ in Chapter 4 (Customs and Trade
      Facilitation) and Articles 2.7 (Goods Re-Entered after Repair or Alteration), 2.13 (Temporary Admission of Goods)
      and 25.66 (Border Enforcement Measures Related to Intellectual Property Rights) of this Agreement shall be understood, in
      relation to the European Union, to refer to the customs territory of the European Union. The customs territory of the
      European Union is the territory referred to in Article 4 of Regulation (EU) No 952/2013 of the European Parliament and of
      the Council (147).


      2.   Unless otherwise specified, this Agreement shall apply, with respect to Mexico, to the land territory, air space, internal
      waters, territorial sea and any areas beyond the territorial seas of Mexico within which Mexico may exercise sovereign rights
      and jurisdiction, as determined by its domestic law, consistent with the UN Convention on the Law of the Sea.



                                                                 Article 33.8
                                                               Amendments


      1.   This Agreement may be amended by written agreement between the Parties. Any amendment shall enter into force on
      the date agreed by the Parties and after the completion of their respective legal requirements and procedures.


      2.    Notwithstanding paragraph 1, this Agreement may be amended in the cases specified in this Agreement by a decision
      of the Trade Council, or the Trade Committee, to modify provisions of or annexes to this Agreement.



                                                                 Article 33.9
                                                              Entry into Force


      1.      This Agreement shall be approved by the Parties in accordance with the Parties' respective internal procedures.


      2.   This Agreement shall enter into force on the first day of the second month following the date on which both Parties
      have notified each other of the completion of their respective internal procedures as referred to in paragraph 1.


      3.   Notifications made in accordance with this Article shall be sent, for the European Union, to the General Secretariat of
      the Council of the European Union and, for Mexico, to the Mexican Ministry of Foreign Affairs.



                                                                Article 33.10
                                                      Relation to Other Agreements


      1.   Titles III to V of the Economic Partnership, Political Coordination and Cooperation Agreement between the European
      Community and its Member States, of the one part, and the United Mexican States, of the other part, signed in Brussels
      on 8 December 1997, shall be repealed and replaced by this Agreement. The Decisions of the Joint Council or the Joint
      Committee listed in Annex 33 shall cease to have effect and be replaced by this Agreement upon its entry into force.

      (147)   Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs
              Code (OJ EU L 269, 10.10.2013, p. 1).

ELI: http://data.europa.eu/eli/agree_internation/2026/1528/oj                                                                       245/975

```

## Localización: página PDF 252

Término: customs duties on originating goods provided for in the tariff lines identified as staging category 3

```text
EN                                                                                                                      OJ L, 31.7.2026

     (b) customs duties on originating goods provided for in the tariff lines identified as staging category 3 in the tariff
         elimination schedule of a Party shall be eliminated in three equal annual stages and such goods shall be duty-free as of
         1 January of year three;

     (c) customs duties on originating goods provided for in the tariff lines identified as staging category 5 in the tariff
         elimination schedule of a Party shall be eliminated in five equal annual stages, and such goods shall be duty-free as of
         1 January of year five;

     (d) customs duties on originating goods provided for in the tariff lines identified as staging category 7 in the tariff
         elimination schedule of a Party shall be eliminated in seven equal annual stages, and such goods shall be duty-free as of
         1 January of year seven;

     (e) customs duties on originating goods provided for in the tariff lines identified as staging category 10 in the tariff
         elimination schedule of a Party shall be eliminated in 10 equal annual stages, and such goods shall be duty-free as of
         1 January of year 10;

     (f) customs duties on originating goods provided for in the tariff lines identified as staging category E in the tariff
         elimination schedule of a Party shall be subject to the base rate of customs duty set out in each Party's schedule;

     (g) customs duties on originating goods provided for in the tariff lines identified as staging category MX7 in the tariff
         elimination schedule of Mexico shall be eliminated as follows:


                 Year                          Ad valorem (%)                                  Specific component


                   1                                16,5                                              Free


                   2                                13,0                                              Free


                   3                                9,5                                               Free


                   4                                7,2                                               Free


                   5                                4,8                                               Free


                   6                                2,4                                               Free


                   7                                Free                                              Free


     (h) customs duties on originating goods provided for in the tariff lines identified as staging category MX10 in the tariff
         elimination schedule of Mexico shall be eliminated in 10 annual stages beginning in year one, and the customs duty for
         such goods shall be duty-free as of 1 January of year 10, as follows:


                          Year                                                    Ad valorem (%)


                           1                                                           19,0


                           2                                                           18,0


                           3                                                           17,0



252/975                                                                   ELI: http://data.europa.eu/eli/agree_internation/2026/1528/oj

```

## Localización: página PDF 308

Término: 1905 90 30

```text
308/975




                                                                                                                                                                                                                                     EN
                                                                Tariff item CN 2016                                     CN 2016 Description                                              Base rate (1)            Staging category


                                                                1905 31 99            – – – – – Other                                                                       9 % + EA MAX 24,2 + AD S/Z (Note 1)          0


                                                                1905 32 05            – – – With a water content exceeding 10 % by weight                                   9 % + EA MAX 20,7 + AD F/M (Note 1)          0


                                                                1905 32 11            – – – – – In immediate packings of a net content not exceeding 85 g                   9 % + EA MAX 24,2 + AD S/Z (Note 1)          0


                                                                1905 32 19            – – – – – Other                                                                       9 % + EA MAX 24,2 + AD S/Z (Note 1)          0


                                                                1905 32 91            – – – – – Salted, whether or not filled                                               9 % + EA MAX 20,7 + AD F/M (Note 1)          0


                                                                1905 32 99            – – – – – Other                                                                       9 % + EA MAX 24,2 + AD S/Z (Note 1)          0


                                                                1905 40 10            – – Rusks                                                                                     9,7 % + EA (Note 1)                  5
ELI: http://data.europa.eu/eli/agree_internation/2026/1528/oj




                                                                1905 40 90            – – Other                                                                                     9,7 % + EA (Note 1)                  5


                                                                1905 90 10            – – Matzos                                                                                   0 % + 15,9 EUR/100 kg                 3


                                                                1905 90 20            – – Communion wafers, empty cachets of a kind suitable for pharmaceutical use,               0 % + 60,5 EUR/100 kg                 3
                                                                                      sealing wafers, rice paper and similar products


                                                                1905 90 30            – – – Bread, not containing added honey, eggs, cheese or fruit, and containing by             9,7 % + EA (Note 1)                  0
                                                                                      weight in the dry matter state not more than 5 % of sugars and not more than 5 % of




                                                                                                                                                                                                                                     OJ L, 31.7.2026
                                                                                      fat


                                                                1905 90 45            – – – Biscuits                                                                        9 % + EA MAX 20,7 + AD F/M (Note 1)          0

```

## Localización: página PDF 309

Término: 1905 90 90

```text
ELI: http://data.europa.eu/eli/agree_internation/2026/1528/oj




                                                                                                                                                                                                                                       OJ L, 31.7.2026
                                                                Tariff item CN 2016                                   CN 2016 Description                                                  Base rate (1)            Staging category


                                                                1905 90 55            – – – Extruded or expanded products, savoury or salted                                  9 % + EA MAX 20,7 + AD F/M (Note 1)          3


                                                                1905 90 60            – – – – With added sweetening matter                                                    9 % + EA MAX 24,2 + AD S/Z (Note 1)          5


                                                                1905 90 90            – – – – Other                                                                           9 % + EA MAX 20,7 + AD F/M (Note 1)          3


                                                                2001 90 30            – – Sweetcorn (Zea mays var. saccharata)                                                   5,1 % + 9,4 EUR/100 kg (Note 3)           7


                                                                2001 90 40            – – Yams, sweet potatoes and similar edible parts of plants containing 5 % or more by      8,3 % + 3,8 EUR/100 kg (Note 3)           0
                                                                                      weight of starch


                                                                2002 10 10            – – Peeled                                                                                             14,4 %                        5


                                                                2002 10 90            – – Other                                                                                              14,4 %                        5


                                                                2002 90 11            – – – In immediate packings of a net content exceeding 1 kg                                            14,4 %                        7


                                                                2002 90 19            – – – In immediate packings of a net content not exceeding 1 kg                                        14,4 %                        7


                                                                2002 90 31            – – – In immediate packings of a net content exceeding 1 kg                                            14,4 %                        7


                                                                2002 90 39            – – – In immediate packings of a net content not exceeding 1 kg                                        14,4 %                        7


                                                                2002 90 91            – – – In immediate packings of a net content exceeding 1 kg                                            14,4 %                        7
309/975




                                                                2002 90 99            – – – In immediate packings of a net content not exceeding 1 kg                                        14,4 %                        7




                                                                                                                                                                                                                                       EN

```
