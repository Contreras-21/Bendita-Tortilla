# Solicitud de cotización: Bendita Tortilla

Documento listo para completar y enviar por el equipo; no enviado.

Cotizar enEUR, con fecha/vigencia, dos operaciones separadas:

1. **Muestras técnicas:** hasta60kg netos,30maíz + 30 harina; plantaBajaCalifornia [municipio/domicilio], destino operadorBeusselstraße44N–Q,10553Berlín [receptor]. Ruta candidataNLU–FRA y traslado frío a Berlín.
2. **Primer ciclo comercial:**411kg netos como referencia máxima basada en meta390kg vendibles; mezcla por pedido, no50/50 obligatoria. Solicitar carga congelada compartida si existe aceptación real. Identificar puerto, línea, escalas y todas las conexiones; cotizarAL4 desdeVeracruz/Altamira y proponer alternativas solo con servicio confirmado.

Antes de fijar tarifa, completar dimensiones/peso de cada caja, volumen, paletización, kg brutos, peso cobrable, temperatura validada, recetas y código provisional. Indicar objetivo de conservación≤−18°C; cualquier rango diferente debe declararse y será evaluado por especialista, sin aprobación automática.

Desglosar: retiro en planta; frío y empaque; tránsito doméstico; despacho exportación; manejo terminal; flete principal; recargos; seguro y exclusiones; puerto/aeropuerto llegada; aduana; depósito congelado; demoras; traslado aBerlín; almacenaje por palé/día; preparación y reparto; impuestos separados. Evitar dobleconteo de tramos incluidos enFCA.

Informar mínimo facturable, dimensiones máximas, factorvolumétrico, disponibilidad congelada de consolidación, fechas corte/salida, tiempo puerta a puerta máximo, aceptaciónSKU, política anteexcursiones, registradores, esperas, alimentación reefer, recepción nocturna, citas, reclamación y responsabilidad. Aclarar qué partidas quedan fuera y cuáles dependen del Meursing/origen.

Adjuntar identificación del operador y contrato de subcontratados. Una referencia comercial en un sitio no demuestra reserva ni capacidad congelada. Comparar tres ofertas con exactamente el mismo alcance. Registrar en plantilla: precioFCA real, logística, seguro, derechos, IVA, almacenamiento, reparto, merma y vida residual. El criterio de aceptación es costo completo porkg vendible inferior al techo negociado con compradores.
