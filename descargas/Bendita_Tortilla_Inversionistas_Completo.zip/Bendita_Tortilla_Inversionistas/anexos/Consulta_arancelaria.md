# Registro de consulta arancelaria

Fecha 09-10-2026. Fuente: Comisión Europea, Access2Markets. Consulta de página dinámica con origen MX y destino DE, producto 19059080 y 19059030.

Enlace 80: https://trade.ec.europa.eu/access-to-markets/en/results?product=19059080&origin=MX&destination=DE

Enlace 30: https://trade.ec.europa.eu/access-to-markets/en/results?product=19059030&origin=MX&destination=DE

Pantalla 80: ERGAOMNES Third country duty9.00%+EA MAX20.70%+ADFM; actualización09 October 2026. Pantalla 30:9.70%+EA. IVA mostrado7%, actualización24 July 2026. No se observa en estas consultas una tasa preferencial que permita afirmar cero para la receta sin clasificación/origen. No se interpreta esa ausencia como dictamen de inelegibilidad bajo todos los regímenes.

Se registró información a nivelCN 8; no se verificó códigoTARIC 10 definitivo. La clasificación30 depende de la definición legal de pan y composición;80 es candidato para otras tortillas. EA yADFM necesitan composición y código adicional. El modelo usa EA 20 yAD F/M 0 exclusivamente como hipótesis ejecutable, con sensibilidad; no son componentes publicados para la receta propia.

Consulta válida como observación de planificación, no como información arancelaria vinculante. Reconfirmar en TARIC/Access2Markets con agente para fecha efectiva, receta, código final, origen ypreferencia. Anexo del tratado en CN 2016 no puede copiarse sin correlación a CN actual.
