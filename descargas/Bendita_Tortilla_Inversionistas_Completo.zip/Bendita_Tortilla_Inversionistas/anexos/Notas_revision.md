# Registro de revisión de la auditoría

Se preservan los puntos1–3.16. Alemania permanece como destino; España/PaísesBajos son comparadores. Se añade zona Moabit y área de pruebasKreuzberg con fuentes primarias. Se elimina selección ponderada sin evidencia y se ejecutan tresindicadores normalizados.

Se distingue muestra60kg de lote comercial por pedido; referencia 411 kg, merma hipotética 5%, meta 390 kg/mes. El antiguo lote 1,000 kg se conserva únicamente para mostrar sobreinventario. El costeo pasa a nivel importador, con FCA, valoraduana, derechos proporcionales, seguro, costos fijos/variables, reserva porcentual y merma física separada. Los precios públicos se convierten a netos y se calcula un techo bajo márgenes declarados; no se inventa cotización mayorista.

Se actualiza clasificación probable 30/80, consulta 9 oct 2026 y calendario del tratado firmado en CN 2016; no se adjudica automáticamente preferencia ni correlación80↔90. Se verifica AL4 y se retira supuesto servicio directoEnsenada–Europa. Se incorporan OGM, acrilamida, microbiología con cambioListeria2026, RGPD y LFPDPPP2025. Se verifica Tlaxcalli yLaTortilla; se eliminaMexhaus.

España2024 se uniforma a3.46%WDI, sin mezclar revisiónINE3.7%. Saldo2022 se presenta con cifras mostradas1,159.40, conservando precisión original en CSV. Se retiran notas académicas y tabla de correcciones del documento principal. Se incluyen todas las gráficas con rutas relativas, datos, fuentes y cálculo.

No se recibieron recetas finales, análisis de laboratorio, costos internos, capacidad real, contratos ni cotizaciones. Su ausencia es un riesgo identificado, no un espacio que se haya llenado con cifras comerciales inventadas. Esta versión corrige y concreta la decisión de inversión, pero no acredita lanzamiento rentable.

Versión 2.1: punto 3.16 ampliado con guías institucionales y recomendaciones específicas por canal de Berlín. Se distingue orientación cultural de propuesta operativa y se evita atribuir conductas universales o validez jurídica a las guías.
